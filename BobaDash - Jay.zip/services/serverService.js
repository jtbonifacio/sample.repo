angular
  .module("bobaApp")
  .service("serverService", function($http, $state) {
    
  })