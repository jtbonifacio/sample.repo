angular
  .module("bobaApp")
  .service("accountService", function($http, $state) {
    
  })