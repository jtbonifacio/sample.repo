angular
  .module("bobaApp")
  .service("homeService", function($http, $state) {

  })