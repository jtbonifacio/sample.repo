angular
  .module("bobaApp")
  .service("customerService", function($http, $state) {
    
   })