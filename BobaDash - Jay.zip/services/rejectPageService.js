angular
  .module("bobaApp")
  .service("rejectPageService", function ($http, $state) {
  })