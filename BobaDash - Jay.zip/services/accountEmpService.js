angular
  .module("bobaApp")
  .service("accountEmpService", function($http, $state) {
    
  })