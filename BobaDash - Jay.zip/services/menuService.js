angular
  .module("bobaApp")
  .service("menuService", function ($http, $state) {
    
  })