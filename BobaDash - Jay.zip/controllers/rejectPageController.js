angular
  .module("bobaApp")
  .controller("rejectPageController", function($scope, $state, $stateParams, rejectPageService) {
    
  })