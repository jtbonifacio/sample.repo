angular
  .module("bobaApp")
  .controller("serverController", function($scope, $state, $stateParams, serverService) {
    
  })