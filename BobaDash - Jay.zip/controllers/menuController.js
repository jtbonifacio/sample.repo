angular
  .module("bobaApp")
  .controller("menuController", function($scope, $state, $stateParams, menuService) {
    
  })